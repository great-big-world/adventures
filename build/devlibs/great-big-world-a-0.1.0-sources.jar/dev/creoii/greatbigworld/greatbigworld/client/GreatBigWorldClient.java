package dev.creoii.greatbigworld.greatbigworld.client;

import net.fabricmc.api.ClientModInitializer;

public class GreatBigWorldClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {

    }
}
