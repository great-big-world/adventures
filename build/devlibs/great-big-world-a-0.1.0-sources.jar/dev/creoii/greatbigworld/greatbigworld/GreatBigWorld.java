package dev.creoii.greatbigworld.greatbigworld;

import net.fabricmc.api.ModInitializer;

public class GreatBigWorld implements ModInitializer {
    @Override
    public void onInitialize() {

    }
}
