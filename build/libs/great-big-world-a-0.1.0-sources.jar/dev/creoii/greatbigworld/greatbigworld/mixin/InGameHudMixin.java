package dev.creoii.greatbigworld.greatbigworld.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_746;

@Mixin(class_329.class)
public class InGameHudMixin {
    @Shadow @Final private class_310 client;

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/hud/SubtitlesHud;render(Lnet/minecraft/client/gui/DrawContext;)V"))
    private void gbw$renderCompassCoordsHud(class_332 context, float tickDelta, CallbackInfo ci) {
        class_746 clientPlayer = client.field_1724;
        if (clientPlayer != null && client.field_1687 != null) {
            List<String> texts = new ArrayList<>();
            if (clientPlayer.method_31548().method_7379(class_1802.field_8251.method_7854())){
                String text = clientPlayer.method_31477() + ", " + clientPlayer.method_31478() + ", " + clientPlayer.method_31479();
                texts.add("\uD83E\uDDED " + text);
            }
            if (clientPlayer.method_31548().method_7379(class_1802.field_8557.method_7854())) {
                long time = client.field_1687.method_8532() * 50;
                Date date = new Date(time);
                texts.add("\uD83D\uDD50 " + new SimpleDateFormat("HH:mm").format(date));
            }

            for (int i = 0; i < texts.size(); ++i) {
                String text = texts.get(i);
                context.method_25303(client.field_1772, text, 5, 5 + (i * 10), 0xffffff);
            }
        }
    }
}
